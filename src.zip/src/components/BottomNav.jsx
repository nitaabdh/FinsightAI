import { useState, useEffect, useRef } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import {
  LayoutDashboard, Receipt, Factory, TrendingUp, ClipboardList, Bot,
  CreditCard, Target, Plus, X, Wallet, HandCoins, ShoppingCart,
} from "lucide-react";
import "./BottomNav.css";

// UMKM: sama polanya kayak Personal — 4 menu utama + tombol "+" buat sisanya.
// Dompet & Utang-Piutang sebelumnya nyempil jadi tab di Laporan, sekarang
// jadi halaman sendiri di sini biar gampang ketemu.
const primaryUMKM = [
  { path: "/dashboard/umkm",           icon: LayoutDashboard, label: "Dashboard" },
  { path: "/dashboard/umkm/transaksi", icon: Receipt,         label: "Transaksi" },
  { path: "/dashboard/umkm/produksi",  icon: Factory,         label: "Produksi" },
  { path: "/dashboard/umkm/laporan",   icon: TrendingUp,      label: "Laporan" },
];
const moreUMKM = [
  { path: "/dashboard/umkm/kasir",         icon: ShoppingCart,   label: "Kasir" },
  { path: "/dashboard/umkm/dompet",        icon: Wallet,          label: "Dompet" },
  { path: "/dashboard/umkm/utang-piutang", icon: HandCoins,       label: "Utang-Piutang" },
  { path: "/dashboard/umkm/catatan",       icon: ClipboardList,   label: "Catatan" },
  { path: "/dashboard/umkm/ai",            icon: Bot,             label: "AI" },
];

// Personal: 4 menu utama tampil langsung (2 kiri, 2 kanan), tombol "+" persis
// di tengah. Sisanya (Laporan, AI) muncul lewat popup pas "+" dipencet. Profil
// SENGAJA nggak dimasukin ke sini — udah ada di avatar pojok kanan atas (PageHeader).
const primaryPersonal = [
  { path: "/dashboard/personal",           icon: LayoutDashboard, label: "Dashboard" },
  { path: "/dashboard/personal/transaksi", icon: CreditCard,      label: "Transaksi" },
  { path: "/dashboard/personal/target",    icon: Target,          label: "Target" },
  { path: "/dashboard/personal/catatan",   icon: ClipboardList,   label: "Catatan" },
];
const morePersonal = [
  { path: "/dashboard/personal/dompet",  icon: Wallet,      label: "Dompet" },
  { path: "/dashboard/personal/laporan", icon: TrendingUp,  label: "Laporan" },
  { path: "/dashboard/personal/ai",      icon: Bot,         label: "AI" },
];

export default function BottomNav() {
  const { user } = useAuth();
  const navigate  = useNavigate();
  const location  = useLocation();
  const [moreOpen, setMoreOpen] = useState(false);
  const wrapRef = useRef(null);

  const isUMKM = user?.mode === "umkm";
  const accent = isUMKM ? "umkm" : "personal";

  const primary = isUMKM ? primaryUMKM : primaryPersonal;
  const more    = isUMKM ? moreUMKM    : morePersonal;

  // Tutup popup pas ganti halaman
  useEffect(() => { setMoreOpen(false); }, [location.pathname]);
  // Tutup popup pas klik di luar. Tombol "+" dan popup-nya sendiri
  // di-stopPropagation, jadi klik di dalam situ TIDAK PERNAH nyampe ke
  // listener ini — gak ada lagi tabrakan/timing-race soal urutan event.
  useEffect(() => {
    if (!moreOpen) return;
    const onOutside = () => setMoreOpen(false);
    document.addEventListener("click", onOutside);
    return () => document.removeEventListener("click", onOutside);
  }, [moreOpen]);

  const isMoreActive = more.some(m => m.path === location.pathname);

  return (
    <div className={`bottom-nav-wrap bottom-nav-wrap--${accent}`} ref={wrapRef}>
      {/* Popup "Menu Lainnya" — muncul di atas tombol + */}
      {moreOpen && (
        <div className="bottom-nav__more-popup" onClick={(e) => e.stopPropagation()}>
          {more.map((item) => {
            const active = location.pathname === item.path;
            return (
              <button
                key={item.path}
                className={`bottom-nav__more-item ${active ? "bottom-nav__more-item--active" : ""}`}
                onClick={() => { navigate(item.path); setMoreOpen(false); }}
              >
                <span className="bottom-nav__icon"><item.icon size={20} /></span>
                <span className="bottom-nav__label">{item.label}</span>
              </button>
            );
          })}
        </div>
      )}

      <nav className={`bottom-nav bottom-nav--${accent}`}>
        <div className="bottom-nav__side">
          {primary.slice(0, 2).map((item) => {
            const active = location.pathname === item.path;
            return (
              <button
                key={item.path}
                className={`bottom-nav__item ${active ? `bottom-nav__item--active bottom-nav__item--${accent}` : ""}`}
                onClick={() => navigate(item.path)}
              >
                <span className="bottom-nav__icon"><item.icon size={20} /></span>
                <span className="bottom-nav__label">{item.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tombol + di tengah — slot lebar tetap, diapit 2 grup sisi kiri/kanan yang
            sama-sama flex:1, jadi posisinya presisi di tengah nggak peduli isi tiap sisi */}
        <button
          className={`bottom-nav__plus ${moreOpen || isMoreActive ? "bottom-nav__plus--active" : ""}`}
          onClick={(e) => { e.stopPropagation(); setMoreOpen((p) => !p); }}
          aria-label="Menu lainnya"
        >
          <span className="bottom-nav__plus-icon">{moreOpen ? <X size={22} /> : <Plus size={24} />}</span>
        </button>

        <div className="bottom-nav__side">
          {primary.slice(2).map((item) => {
            const active = location.pathname === item.path;
            return (
              <button
                key={item.path}
                className={`bottom-nav__item ${active ? `bottom-nav__item--active bottom-nav__item--${accent}` : ""}`}
                onClick={() => navigate(item.path)}
              >
                <span className="bottom-nav__icon"><item.icon size={20} /></span>
                <span className="bottom-nav__label">{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
